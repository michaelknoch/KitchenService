declare module 'current-week-number';
declare module '@slack/client';